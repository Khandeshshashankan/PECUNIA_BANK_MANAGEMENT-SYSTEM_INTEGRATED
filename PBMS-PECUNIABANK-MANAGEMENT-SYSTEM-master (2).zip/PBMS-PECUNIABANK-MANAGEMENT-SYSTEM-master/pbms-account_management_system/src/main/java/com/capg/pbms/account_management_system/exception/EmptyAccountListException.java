package com.capg.pbms.account_management_system.exception;

public class EmptyAccountListException extends Exception {
	public EmptyAccountListException(String msg) {
		super(msg);
	}

}
