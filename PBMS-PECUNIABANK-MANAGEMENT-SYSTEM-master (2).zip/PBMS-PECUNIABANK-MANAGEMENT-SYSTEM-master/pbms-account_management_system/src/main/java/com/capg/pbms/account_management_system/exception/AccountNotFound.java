package com.capg.pbms.account_management_system.exception;

public class AccountNotFound extends Exception {
	public AccountNotFound(String msg) {
		super(msg);
	}

}
