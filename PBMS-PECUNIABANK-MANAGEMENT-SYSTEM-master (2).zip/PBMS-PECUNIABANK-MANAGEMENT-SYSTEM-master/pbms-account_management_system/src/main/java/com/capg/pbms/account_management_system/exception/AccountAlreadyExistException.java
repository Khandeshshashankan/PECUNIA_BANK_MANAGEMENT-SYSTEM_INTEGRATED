package com.capg.pbms.account_management_system.exception;

public class AccountAlreadyExistException extends Exception {
	public AccountAlreadyExistException(String msg) {
		super(msg);
	}

}
