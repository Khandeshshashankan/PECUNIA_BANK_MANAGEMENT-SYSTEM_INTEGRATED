package com.capgemini.pbms.account_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PbmsAccountManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
