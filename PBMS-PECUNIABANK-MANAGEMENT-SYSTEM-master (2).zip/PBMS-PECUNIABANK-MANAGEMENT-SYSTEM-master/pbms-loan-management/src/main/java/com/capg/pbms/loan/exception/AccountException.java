package com.capg.pbms.loan.exception;

public class AccountException extends RuntimeException {
	public AccountException(String message) {
		super(message);
	}
}