package com.capg.pbms.loan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PbmsLoanManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
