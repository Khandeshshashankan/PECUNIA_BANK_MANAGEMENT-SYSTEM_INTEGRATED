package com.capg.pbms.transaction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PbmsTransactionsMangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
