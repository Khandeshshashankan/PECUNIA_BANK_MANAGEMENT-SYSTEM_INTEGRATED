package com.capg.pbms.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PbmsEurekaNamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
